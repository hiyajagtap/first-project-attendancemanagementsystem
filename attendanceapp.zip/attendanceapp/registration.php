<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" href="StyleSheet.css">
        <title>Document</title>

        <style>
        {
    margin: 0;
    padding: 0;
    box-sizing:border-box;
    font-family: sans-serif;
}
body{
    display:flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}
.container{
    max-width: 650px;
    padding: 28px;
    margin:0 28px;
    box-shadow: 0 15px 20px #ABB289;
}
h2{
    font-size: 20px;
    font-weight: 600;
    text-align: left;
    color: #2f4f4f;
    padding-bottom: 8px;
    border-bottom: 1px soloid silver;
}

.content{
    display:flex;
    flex-wrap: wrap;
    justify-content: space-between;
    padding: 20px 0;
}

.input-box{
    display: flex;
    flex-wrap: wrap;
    width: 50%;
    padding-bottom: 15px;
}

.input-box:nth-child(2n){
    justify-content: end;
}
.input-box label, .gender-title{
    width: 95%;
    color:#2f4f4f;
    font-weight: bold;
    margin: 5px;
}

.gender-title{
    font-size: 16px;
}
.input-box input{
    height:40px;
    width:95%;
    padding: 0 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    outline: none;
}
.input-box input:is(:focus, :valid){
    box-shadow: 0 3px 6px rgba(0,0,0) ;

}
.gender-category{
    color: gray;
}
.gender-category label{
    padding: 0 20px 0 5px;
    font-size:14px;
}
.gender-category label, .gender-category input{
    cursor: pointer;
}
.alert p{
    font-size: 14px;
    font-style: italic;
    color:dimgray;
    margin: 5px 0;
    padding: 10px;
}
    
.button-container button{
    width:100%;
    margin-top: 10px;
    padding: 10px;
    display: block;
    font-size: 20px;
    colour: #fff;
    border: none;
    border-radius: 5px;
    background-image: linear-gradient(to right, #aa076b,#61045f);
}
.button-container button:hover{
    background-image:linear-gradient(to right, #61045f,#aa076b  );
}
@media(max-width:200px);
.container{
    min-width: 280px;
}
.content{
    max-height: 380px;
    overflow: auto;
}
.input-box{
    margin-bottom: 12px;
    width: 100%;
}
.input-box:nth-child(2n){
    justify-content: space-between;
}
.gender-category{
    display: flex;
    justify-content: space-between;
    width: 60%;
}
</style>

    </head>
    <body>
        <div class="container">
            <form action="login.php" method="post">
                <h2>Registration</h2>
                <div class="content">
                    <div class="input-box">
                        <label for="name">User Name</label>
                        <input type="text" placeholder="Enter User name" name="uname" required>
                    </div>
                    <div class="input-box">
                        <label for="email">Email</label>
                        <input type="email" placeholder="Enter email" name="name" required>
                    </div>
                    <div class="input-box">
                        <label for="name">Password</label>
                        <input type="password" placeholder="Enter new password" name="password" required>
                    </div>
                    <div class="input-box">
                        <label for="Cpassword">Confirm Password</label>
                        <input type="password" placeholder="Confirm password" name="confirmPassword" required>
                    </div>
                    <span class="gender-title">Gender</span>
                    <div class="gender-category">
                        <input type="radio" name="gender" id="male">
                        <label for="gender">Male</label>
                        <input type="radio" name="gender" id="female">
                        <label for="gender">Female</label>

                    </div>
                 </div>
                 <div class="alert">
                    <p>By clicking signup you agree to our terms,Privacy and Cookies Policy</p>

                 </div>
                 <div class="button-container">
                    <button type="submit">Register</button>
                 </div>


             </form>
        </div>
    </body>
</html>